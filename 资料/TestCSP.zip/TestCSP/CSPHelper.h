#pragma once
class CCSPHelper
{
public:
	CCSPHelper(void);
	~CCSPHelper(void);
};

