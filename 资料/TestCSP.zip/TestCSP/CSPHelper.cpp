#include "stdafx.h"
#include "CSPHelper.h"


CCSPHelper::CCSPHelper(void)
{
}


CCSPHelper::~CCSPHelper(void)
{
}
